<?php 

	require_once 'config.php';
	
	
		
		if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']))
		{
			$user = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $userid = rand(10000000000,99999999999);
            
            date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s'); 
        
			$log_in="INSERT INTO `users`(`userid`, `username`, `email`, `password`, `created_at`, `nickname`, `diamonds`, `chips`) VALUES ('$userid','$user','$email','$password','$date','$user','1000','10000')";
			
			$log_in_rs=mysqli_query($conn,$log_in);
			//$insid = mysqli_insert_id($conn);
			
			
			if($log_in_rs)
			{ 
			    $sql = "SELECT * FROM `users` WHERE userid='$userid'";
			    $qrry=mysqli_query($conn,$sql);
			    $row = mysqli_fetch_array($qrry);
			    
			    echo "true".",".$row['userid'].",".$row['username'].",".$row['email'].",".$row['nickname'].",".$row['diamonds'].",".$row['chips'];
		
			}	
			else
			{
    			    echo "false";
    			
			}
			
			
						
		}
		
		
		
	
	
	
