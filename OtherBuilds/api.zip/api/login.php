<?php 

	require_once 'config.php';
	
	
		
		if(isset($_POST['username']) && isset($_POST['password']))
		{
			$user = $_POST['username'];
			$pass = $_POST['password'];
		    
           
			$log_in="SELECT * FROM users WHERE username='$user' AND password='$pass'";
			
			$log_in_rs=mysqli_query($conn,$log_in);
			$rows = mysqli_num_rows($log_in_rs);
			//$rd=mysqli_fetch_object($log_in_rs);
			if($rows > 0)
			{ 
			   while($rd = mysqli_fetch_array($log_in_rs)){
			    echo "true".",".$rd['userid'].",".$rd['username'].",".$rd['email'].",".$rd['nickname'].",".$rd['diamonds'].",".$rd['chips'].",".$rd['created_at'].","."http://keita.co.in/arowanaentertainment/api/".$rd['profile'].",";
			    $log="SELECT * FROM `club` WHERE user_name='".$rd['username']."'";
		
			$logs=mysqli_query($conn,$log);
			$rowd = mysqli_num_rows($logs);
			while($ro = mysqli_fetch_array($logs)){
			    echo $ro["clb_id"]."#".$ro["club_name"]."#".$ro["des"]."#".$ro["title"]."#"."http://keita.co.in/arowanaentertainment/api/".$ro["image"]."#".$ro["clb_level"]."#".$ro["clb_bal"]."#"."nothing"."#".$ro["members"]."*";
			        
			}
			}
			}	
			else
			{
    			    echo "false";
    			
			}
			
			
				
						
		}
		
		
		
	
	
	
