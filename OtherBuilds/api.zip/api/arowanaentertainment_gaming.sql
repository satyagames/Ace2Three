-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 22, 2021 at 03:34 AM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arowanaentertainment_gaming`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'admin@admin.com');

-- --------------------------------------------------------

--
-- Table structure for table `club`
--

CREATE TABLE `club` (
  `club_id` int(11) NOT NULL,
  `club_name` varchar(150) NOT NULL,
  `des` text NOT NULL,
  `title` varchar(200) NOT NULL,
  `user_name` varchar(150) NOT NULL,
  `clb_id` varchar(150) NOT NULL,
  `members` int(11) NOT NULL,
  `admins` int(11) NOT NULL,
  `unions` int(11) NOT NULL,
  `clb_chips` int(15) NOT NULL,
  `image` varchar(250) NOT NULL,
  `clb_level` varchar(100) NOT NULL,
  `clb_bal` varchar(150) NOT NULL,
  `people` varchar(100) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `club`
--

INSERT INTO `club` (`club_id`, `club_name`, `des`, `title`, `user_name`, `clb_id`, `members`, `admins`, `unions`, `clb_chips`, `image`, `clb_level`, `clb_bal`, `people`, `created_at`) VALUES
(1, 'asdf', 'dfrr', 'Owner', 'asdf1234', '633140', 25, 1, 1, 100, 'uploads/club/profile.png', '1', '1000', '', '2021-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `otp_new_email`
--

CREATE TABLE `otp_new_email` (
  `id` int(11) NOT NULL,
  `otp` varchar(110) NOT NULL,
  `email` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp_new_email`
--

INSERT INTO `otp_new_email` (`id`, `otp`, `email`) VALUES
(1, '214459', 'vuddanda.ramesh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `clubid` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `userid`, `clubid`, `amount`, `created`) VALUES
(1, '49795659873', '100843', '15', '2020-09-29 12:24:46');

-- --------------------------------------------------------

--
-- Table structure for table `ring_table`
--

CREATE TABLE `ring_table` (
  `id` int(11) NOT NULL,
  `table_id` varchar(50) NOT NULL,
  `clubid` varchar(100) NOT NULL,
  `TableName` varchar(100) NOT NULL,
  `Mixed` varchar(100) NOT NULL,
  `Game` varchar(100) NOT NULL,
  `Anonymous_Table` varchar(100) NOT NULL,
  `BanChat` varchar(100) NOT NULL,
  `TableSize` varchar(100) NOT NULL,
  `ActionTime` varchar(100) NOT NULL,
  `BuyIn` varchar(100) NOT NULL,
  `Blinds` varchar(100) NOT NULL,
  `Ante` varchar(100) NOT NULL,
  `CareerPercent` varchar(100) NOT NULL,
  `MaintainPercent` varchar(100) NOT NULL,
  `MaintainHash` varchar(100) NOT NULL,
  `AutoStart` varchar(100) NOT NULL,
  `AutoExtension` varchar(100) NOT NULL,
  `AutoRestart` varchar(100) NOT NULL,
  `Straddle` varchar(100) NOT NULL,
  `Insurance` varchar(100) NOT NULL,
  `RunMultiTimes` varchar(100) NOT NULL,
  `Fee` varchar(100) NOT NULL,
  `FeeCap` varchar(100) NOT NULL,
  `SameAgent` varchar(100) NOT NULL,
  `BuyinAuthorization` varchar(100) NOT NULL,
  `Restrict_Device` varchar(100) NOT NULL,
  `Restrict_Observers` varchar(100) NOT NULL,
  `GPSRestriction` varchar(100) NOT NULL,
  `IPRestriction` varchar(100) NOT NULL,
  `HideClubname` varchar(100) NOT NULL,
  `GameLength` varchar(100) NOT NULL,
  `created` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tournament_table`
--

CREATE TABLE `tournament_table` (
  `id` int(11) NOT NULL,
  `table_id` varchar(50) NOT NULL,
  `clubid` varchar(11) NOT NULL,
  `TableName` varchar(100) NOT NULL,
  `TableDescription` varchar(100) NOT NULL,
  `Mixed` varchar(100) NOT NULL,
  `Game` varchar(100) NOT NULL,
  `NextStep` varchar(100) NOT NULL,
  `BanChat` varchar(100) NOT NULL,
  `TableSize` varchar(100) NOT NULL,
  `ActionTime` varchar(100) NOT NULL,
  `Fee` varchar(100) NOT NULL,
  `HideClubname` varchar(100) NOT NULL,
  `CustomBuyin` varchar(100) NOT NULL,
  `Buyin` varchar(100) NOT NULL,
  `CustomRebuy` varchar(100) NOT NULL,
  `Rebuy` varchar(100) NOT NULL,
  `MaxRebuys` varchar(100) NOT NULL,
  `RebuyFee` varchar(100) NOT NULL,
  `CustomAddon` varchar(100) NOT NULL,
  `Addon` varchar(100) NOT NULL,
  `AddonFee` varchar(100) NOT NULL,
  `KoBounty` varchar(100) NOT NULL,
  `GTDPrizepool` varchar(100) NOT NULL,
  `Ante` varchar(100) NOT NULL,
  `AuthorizeToRegister` varchar(100) NOT NULL,
  `BlindStructure` varchar(100) NOT NULL,
  `PayoutStructure` varchar(100) NOT NULL,
  `StartChips` varchar(100) NOT NULL,
  `BlindsUp` varchar(100) NOT NULL,
  `LateReg` varchar(100) NOT NULL,
  `Players` varchar(100) NOT NULL,
  `BreakTime` varchar(100) NOT NULL,
  `BreakEvery` varchar(100) NOT NULL,
  `StartTime` varchar(100) NOT NULL,
  `created` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `userid` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` varchar(100) NOT NULL,
  `nickname` varchar(110) NOT NULL,
  `diamonds` varchar(100) NOT NULL,
  `chips` varchar(150) NOT NULL,
  `otp` varchar(100) NOT NULL,
  `profile` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userid`, `username`, `email`, `password`, `created_at`, `nickname`, `diamonds`, `chips`, `otp`, `profile`) VALUES
(1, '68284170627', 'Laguinhas', 'laguinhas@gmail.com', '123456j', '07-09-2020 10:14:49', 'Laguinhas', '1000', '10000', '', ''),
(2, '74545708609', 'ankitkumawat', 'ankitkumawat2828@gmail.com', '123456h', '08-09-2020 07:46:46', 'ankitkumawat', '1000', '10000', '68977', 'uploads/bachi1984543.png'),
(3, '49795659873', 'bachi1984', 'rameshgames@gmail.com', 'asdf1234', '08-09-2020 10:21:15', 'bachi2020', '1000', '9640', '8082', 'uploads/bachi1984profile.png'),
(4, '28011366288', 'satyagames', 'satyagames@gmail.com', 'satya.123', '08-09-2020 12:15:58', 'Satya123', '1000', '10000', '', 'uploads/satyagames423.png'),
(5, '82979510400', 'Pedro1', 'bdgasianapps@gmail.com', 'futebol16', '09-09-2020 08:23:12', 'Pedro1', '1000', '10000', '', ''),
(6, '56270829377', 'Rakesh16', 'pushpam.prasun@gmail.com', 'rakesh16', '13-09-2020 09:39:23', 'Neha15', '1000', '10000', '', 'uploads/Rakesh16686.png'),
(7, '10466269441', 'rakesh', 'rakesh.pandey16@gmail.com', '123456r', '13-09-2020 11:16:04', 'Rakesh16', '1000', '10000', '110240', 'uploads/rakesh932.png'),
(8, '7167862253', 'Anaysha', 'neha.rakesh10@gmail.com', 'neha1993', '13-09-2020 09:56:37', 'Anaysha', '1000', '10000', '175753', 'uploads/Anaysha913.png'),
(9, '24539390108', 'rrrrrr1111111qqq', 'rakesh.pandey16@yahoo.com', '123456r', '17-09-2020 10:05:45', 'rrrrrr1111111qqq', '1000', '10000', '', ''),
(10, '38728979721', '123456r', 'rakesh@mailinator.com', '123456r', '17-09-2020 10:07:02', 'Rakeshp16', '1000', '10000', '', 'uploads/123456r582.png'),
(11, '28460803133', 'Princess', 'neha@mailinator.com', 'Neha1993', '21-09-2020 10:51:20', 'Princess', '1000', '10000', '', 'uploads/Princess401.png'),
(12, '39497004579', 'Pandey', 'neha1@mailinator.com', 'neha1993', '22-09-2020 10:06:43', 'Pandey', '1000', '10000', '898787', 'uploads/Pandey617.png'),
(13, '76464005734', 'Angels', 'angel@mailinator.com', 'Neha1993', '25-09-2020 18:22:29', 'Angels', '1000', '10000', '', 'uploads/Angels179.png'),
(14, '60796917897', 'Pushp07', 'pushpam.pandey@gmail.com', '12345678p', '27-09-2020 10:10:55', 'Pushp07', '1000', '10000', '', ''),
(15, '47229087912', 'kalaw', 'kalawati@mailinator.com', 'neha1993', '28-09-2020 10:22:59', 'Samw123456', '1000', '10000', '', 'uploads/kalaw492.png'),
(16, '96892259128', 'pushpam07', 'pp@mailinator.com', 'pp12345678', '28-09-2020 12:25:38', 'pp07123456', '1000', '10000', '', 'uploads/pushpam07512.png'),
(17, '96159862115', 'sneha s', 'sneha@mailinator.com', 'Neha1993', '30-09-2020 10:42:45', 'sneha s', '1000', '10000', '', 'uploads/sneha s16.png'),
(18, '40283196151', 'ana', 'ana@mailinator.com', 'Neha1993', '02-10-2020 13:21:09', 'ana', '1000', '10000', '', 'uploads/ana777.png'),
(19, '68113916013', '123456rr', 'r@mailinator.com', '123456rr', '02-10-2020 07:19:25', '123456rr', '1000', '10000', '159108', 'uploads/123456rr678.png'),
(20, '53161208777', 'ana', 'abc@mailinator.com', 'neha1993', '05-10-2020 10:25:10', 'ana', '1000', '10000', '', 'uploads/ana777.png'),
(21, '39764417121', 'n', 'n@mailinator.com', 'neha1993', '05-10-2020 10:43:41', 'n', '1000', '10000', '', ''),
(22, '91177704556', 'ana', 'a@mailinator.com', 'neha1993', '05-10-2020 10:45:57', 'ana', '1000', '10000', '', 'uploads/ana777.png'),
(23, '26428324882', 'n', 'n@nmailinator.com', 'rakesh1984', '05-10-2020 10:49:11', 'n', '1000', '10000', '', ''),
(24, '64206113020', 'ana', 'an@mailinator.com', 'rakesh1984', '05-10-2020 10:51:03', 'ana', '1000', '10000', '', 'uploads/ana777.png'),
(25, '21637861377', 'neha1234', 'neha3@mailinator.com', 'Neha1993', '06-10-2020 14:50:43', 'neha1234', '1000', '10000', '945926', 'uploads/neha1234455.png'),
(26, '92478225924', 'hiring100', 'hiring.true100@yahoo.com', 'neha1993', '06-10-2020 15:14:24', 'hiring100', '1000', '10000', '530312', ''),
(27, '16696058975', 'asdf1234', 'vuddanda.ramesh@gmail.com', 'asdf1234', '06-10-2020 07:08:41', 'fdsa1234', '1000', '9880', '', 'uploads/asdf1234profile.png'),
(28, '55789771571', 'rams1234', 'rams1234@gmail.com', 'asdf1234', '06-10-2020 07:11:37', 'rams1234', '1000', '9880', '', 'uploads/rams1234profile.png'),
(29, '92271910819', '1234567r', 'tester.rakesh@gmail.com', '1234567r', '07-10-2020 09:56:00', '1234567r', '1000', '10000', '391459', ''),
(38, '54424319229', 'dvpvarma', 'dvpvarma9999@gmail.com', '123456', '09-10-2020 15:33:35', 'dvpvarma', '1000', '10000', '947444', ''),
(39, '37665699479', 'anahita', 'anahita@mailinator.com', 'neha1993', '09-10-2020 17:13:31', 'anahita', '1000', '10000', '', 'uploads/anahita760.png'),
(40, '82424262698', 'shayna', 'sha@mailinator.com', 'neha1993', '10-10-2020 12:53:47', 'shayna', '1000', '10000', '', 'uploads/shayna170.png'),
(41, '1391615826', 'saanvi', 'saanvi@mailinator.com', 'neha1993', '10-10-2020 10:29:29', 'saanvi', '1000', '10000', '95538', 'uploads/saanvi180.png'),
(42, '44800590438', 'kalama', 'hiring.tru100@outlook.com', 'neha1993', '11-10-2020 12:31:42', 'kalama', '1000', '10000', '444926', 'uploads/kalama196.png'),
(43, '48813259789', 'ginger', 'hiring.true200@outlook.com', 'neha1993', '11-10-2020 12:35:02', 'ginger', '1000', '10000', '', ''),
(44, '6837667422', 'rakeshr', 'rakeshr@mailinator.com', 'rakesh1', '11-10-2020 16:24:35', 'rakeshr', '1000', '10000', '', 'uploads/rakeshr271.png'),
(45, '65030764095', 'sravz1234', 'nsravani562@gmail.com', 'asdf1234', '11-10-2020 17:23:03', 'sravz1234', '1000', '10000', '', ''),
(46, '66811245895', 'pushpa', 'pushpa@mailinator.com', 'neha1984', '12-10-2020 16:08:24', 'pushpa', '1000', '10000', '539270', 'uploads/pushpa39.png'),
(47, '93666960229', 'jackson', 'jackson@mailinator.com', 'neha1993', '12-10-2020 06:35:21', 'jackson', '1000', '10000', '', ''),
(48, '60255824877', 'mihika', 'mihika@mailinator.com', 'neha1993', '12-10-2020 08:54:02', 'mihika', '1000', '10000', '', 'uploads/mihika861.png'),
(49, '79811832455', 'pr', 'pr@mailinator.com', 'neha1993', '13-10-2020 14:44:37', 'pr', '1000', '10000', '501803', ''),
(50, '51001957987', 'nick123456', 'nick@mailinator.com', 'nick123456', '14-10-2020 09:54:23', 'nick123456', '1000', '10000', '188621', ''),
(51, '71295528831', 'shivansh', 'shiv@mailinator.com', 'neha1993', '14-10-2020 14:26:13', 'shivansh', '1000', '10000', '', ''),
(52, '35329745655', 'shiv12', 'shiva@mailinator.com', 'neha1993', '14-10-2020 14:30:42', 'shiv12', '1000', '10000', '', ''),
(53, '3866870002', 'mike12', 'mike@mailinator.com', 'neha1993', '14-10-2020 15:07:54', 'mike12', '1000', '10000', '', ''),
(54, '13652196745', 'john123456', 'john@mailinator.com', 'john123456', '14-10-2020 16:27:09', 'john123456', '1000', '10000', '', 'uploads/john123456667.png'),
(55, '46715848060', 'neha93', 'neha93@mailinator.com', 'neha1993', '14-10-2020 17:38:29', 'neha93', '1000', '10000', '', ''),
(56, '41154614174', 'neha12', 'neha12@mailinator.com', 'neha1993', '14-10-2020 17:42:46', 'neha12', '1000', '10000', '', ''),
(57, '78765724784', 'neha10', 'neha10@mailinator.com', 'neha1993', '14-10-2020 18:17:14', 'neha10', '1000', '10000', '', ''),
(58, '90226156703', 'neha20', 'neha20@mailinator.com', 'neha1993', '14-10-2020 18:19:32', 'neha20', '1000', '10000', '', ''),
(59, '80064648449', 'zxcv1234', 'asdf@gm.com', 'asdf1234', '14-10-2020 08:49:56', 'zxcv1234', '1000', '10000', '', ''),
(60, '21512335028', 'peter123456', 'peter@mailinator.com', 'peter123456', '14-10-2020 09:03:47', 'peter123456', '1000', '10000', '722800', ''),
(61, '89520561503', 'neharp', 'rp@mailinator.com', 'neha1993', '14-10-2020 09:56:31', 'neharp', '1000', '10000', '', ''),
(62, '50511449530', 'neha11', '11@mailinator.com', 'neha1993', '14-10-2020 10:00:36', 'neha11', '1000', '10000', '929885', 'uploads/neha11539.png'),
(63, '77619415100', 'sam123456', 'sam@mailinator.com', 'sam123456', '15-10-2020 12:19:25', 'sam123456', '1000', '10000', '363611', 'uploads/sam12345685.png'),
(64, '63150613806', 'pedro16', 'regueiracris@hotmail.com', 'pedro16', '15-10-2020 18:27:09', 'pedro16', '1000', '10000', '', ''),
(65, '86139640793', 'prince', 'p@mailinator.com', 'neha1984', '16-10-2020 09:54:01', 'prince', '1000', '10000', '', 'uploads/prince115.png'),
(66, '5686910591', 'pamela', 'pamela@mailinator.com', 'neha1993', '18-10-2020 13:02:17', 'pamela', '1000', '10000', '738503', 'uploads/pamela23.png'),
(67, '12908011520', 'nehaa', 'nn@mailinator.com', 'neha1993', '19-10-2020 10:38:27', 'nehaa', '1000', '10000', '', 'uploads/nehaa705.png'),
(68, '45201237472', 'sam1234567', 'sam1234567@grr.la', 'sam1234567', '19-10-2020 11:30:59', 'sam1234567', '1000', '10000', '803902', 'uploads/sam1234567319.png'),
(69, '45051738259', 'swaraa', 'swara@mailinator.com', 'neha1993', '22-10-2020 12:56:57', 'swaraa', '1000', '10000', '238954', ''),
(70, '59117575981', 'yellow', 'yellow@mailinator.com', 'neha1993', '22-10-2020 13:10:52', 'yellow', '1000', '10000', '', ''),
(71, '4831881240', 'alex123456', 'akex@mailinator.com', 'alex123456', '22-10-2020 08:20:30', 'alex123456', '1000', '10000', '128259', ''),
(72, '8427368194', 'cristina', 'cristinasilva-16@hotmail.com', 'futebol16', '25-10-2020 12:41:41', 'cristina', '1000', '10000', '', ''),
(73, '60783825129', 'ankit1992', 'amit@pillersofttechnologies.com', '123456789a@a', '28-10-2020 09:59:30', 'ankit1992', '1000', '10000', '', ''),
(74, '35331416968', 'pushpam779', 'pushpam@mailinator.com', 'pp12345678', '28-10-2020 10:28:41', 'pushpam779', '1000', '10000', '', ''),
(75, '96018333671', 'OH_LINA', 'jlfjesus@gmail.com', 'mamamia11', '03-11-2020 07:44:37', 'OH_LINA', '1000', '10000', '', ''),
(76, '68663571408', 'Iron4Profit', 'olobodaportela@gmail.com', 'Xopokerm81133', '03-11-2020 07:51:00', 'Iron4Profit', '1000', '10000', '', ''),
(77, '51789502575', 'pedro2', 'paymentswalletusd@gmail.com', 'futebol16', '20-11-2020 07:12:02', 'pedro2', '1000', '10000', '', ''),
(78, '31961479273', 'qwer1234', 'qwer1234@g.com', 'asdf1234', '2021-02-28 17:43:34', 'qwer1234', '1000', '10000', '', ''),
(79, '95500047688', 'john1234', 'asdf@g.com', 'asdf1234', '2021-03-02 19:31:55', 'john1234', '1000', '10000', '', ''),
(80, '43240043582', 'raj1234', 'raj1234@g.com', 'asdf1234', '2021-03-02 19:33:11', 'raj1234', '1000', '10000', '', ''),
(81, '65831211960', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:53', 'wdsd', '1000', '10000', '', ''),
(82, '39535023415', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:53', 'wdsd', '1000', '10000', '', ''),
(83, '44275652567', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:54', 'wdsd', '1000', '10000', '', ''),
(84, '72084776319', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:54', 'wdsd', '1000', '10000', '', ''),
(85, '30065536600', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:55', 'wdsd', '1000', '10000', '', ''),
(86, '83404078173', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:55', 'wdsd', '1000', '10000', '', ''),
(87, '88650213638', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:56', 'wdsd', '1000', '10000', '', ''),
(88, '55395172938', 'wdsd', 'asdsad', 'sadsd', '2021-05-21 22:16:57', 'wdsd', '1000', '10000', '', ''),
(89, '73016387131', '', '', '', '2021-05-22 10:39:00', '', '1000', '10000', '', ''),
(90, '45115262977', 'xmen', 'xmen@gmail.com', 'xmen123', '2021-05-22 10:46:03', 'xmen', '1000', '10000', '', ''),
(91, '12903010629', 'xmen1', 'xmen1', 'xmen123', '2021-05-22 13:05:26', 'xmen1', '1000', '10000', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `club`
--
ALTER TABLE `club`
  ADD PRIMARY KEY (`club_id`);

--
-- Indexes for table `otp_new_email`
--
ALTER TABLE `otp_new_email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ring_table`
--
ALTER TABLE `ring_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tournament_table`
--
ALTER TABLE `tournament_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `club`
--
ALTER TABLE `club`
  MODIFY `club_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `otp_new_email`
--
ALTER TABLE `otp_new_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ring_table`
--
ALTER TABLE `ring_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tournament_table`
--
ALTER TABLE `tournament_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
