<?php 

	require_once 'config.php';
	
	
		
		if(isset($_POST['email']))
		{
			$clubid = $_POST['email'];
		    
           
			$log_in="SELECT * FROM users WHERE email='$clubid'";
			
			$log_in_rs=mysqli_query($conn,$log_in);
			$rows = mysqli_num_rows($log_in_rs);
			//$rd=mysqli_fetch_object($log_in_rs);
			if($rows > 0)
			{ 
			   echo "true";
			}	
			else
			{
    			    echo "false";
    			
			}
			
			
				
						
		}
		
		
		
	
	
	
